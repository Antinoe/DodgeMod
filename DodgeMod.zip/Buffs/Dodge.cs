using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;

namespace DodgeMod.Buffs
{
    public class Dodge : ModBuff
    {
        public override void SetDefaults()
        {
            DisplayName.SetDefault("Dodging");
            Description.SetDefault("You cannot be struck.");
            Main.buffNoTimeDisplay[Type] = false;
            Main.debuff[Type] = false;
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.immune = true;
			//player.immuneTime = 30;
        }
    }
}
