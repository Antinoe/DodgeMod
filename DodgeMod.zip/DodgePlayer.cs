﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace DodgeMod
{
    public class DodgePlayer : ModPlayer
    {
		//Thank you for the remastered code, Scooterboot.
		int dodgeCoolDown = 0;
		public override void PostUpdate()
		{
		if(dodgeCoolDown <= 0)
		{
			if (DodgeMod.Dodge.JustPressed)
			{
			int dodgeDir = player.direction;
			if(player.controlRight)
				{
				dodgeDir = 1;
				}
			else if(player.controlLeft)
				{
				dodgeDir = -1;
				}
			player.delayUseItem = true;
			player.immune = true;
			player.immuneTime = 30;
			dodgeCoolDown = 50;
			if(player.velocity.Y == 0)
				{
				player.velocity.X = 5 * dodgeDir;
				}
			else
				{
				player.velocity.X = 5 * dodgeDir;
				}
			}
		}
		else
			{
			dodgeCoolDown--;
			}
		}
		
		public static DodgePlayer ModPlayer(Player player)
		{
			return player.GetModPlayer<DodgePlayer>();
		}
    }
}
