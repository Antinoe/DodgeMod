using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;


namespace DodgeMod
{
	public class DodgeMod : Mod
	{
		public static ModHotKey Dodge;
		
        public override void Load()
        {
            Dodge = RegisterHotKey("Dodge", "T");
        }
        
        public override void Unload()
        {
            Dodge = null;
        }
    }
}
